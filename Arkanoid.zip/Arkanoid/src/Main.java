import javax.swing.*;
import System.GameCycles;
import System.Settings;

public class Main {

    public static void main(String[] args) {

        Settings.initGame();

    }

}